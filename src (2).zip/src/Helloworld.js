import React from "react"

const Helloworld = ({tech})=>{
	return(	
	<div>
		
		{tech}
	</div>
	);
}

export default Helloworld;