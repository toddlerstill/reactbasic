import React, { Component } from 'react';
import {Provider} from 'react-redux';
import { BrowserRouter as Router, Route, Link, Switch} from 'react-router-dom'
import {Helmet} from "react-helmet";
import Helloworld from "./Helloworld";
import Parent from './footer'
import reducer from './redux/reducers'
import './App.css';
import Apicall1 from './apicall'
import {createStore} from 'redux'

const initialState = {tech: "React"}

const store = createStore(reducer, initialState);

class LearnRedux extends React.Component{
	
	render(){
	
	 return <LearnRedux tech={store.getState().tech}/>
	
	
	
	}
}



class NavRoute extends React.Component{
	
	render(){
		
		return(
		
	<Router>
      <div>
        <ul>
          <li><Link to="/">Home</Link></li>
			<li><Link to='/Clock/header'>Clock</Link></li>
			<li><Link to='/header'>header</Link></li>
			<li><Link to='/IMDB'>Apicall</Link></li>
			<li><Link to="/Dk">Dunkrik</Link></li>
			<li><Link to="/simplefn">Sample Fn</Link></li>
			
          
        </ul>
		

        <hr />

        <Route exact path="/" component={App} />
		<Route exact path="/Clock/header" component={Clock} />
		<Route path="/header" component={Header} />
		<Route path="/IMDB" component={Apicall} />
		<Route path='/Dk' component={Apicall1} />
        <Route path='/simplefn' component={SampleFn} />
		
      </div>
	  
    </Router>
		
		);
		
	}
}

class App extends Component {
  constructor(props){
	  super(props);
  this.state = {
	  title: "Place Holder title",
	  Resdata:[]
	  }
  }
  
  
  ChangeTheWorld = (NewTitle) => {
	  this.setState({title: NewTitle});
  }
  render() {
	  const{Resdata}=this.state;
	  
    return (
      <div className="App">
			<div onClick={this.props.sample}>Click Here</div>
			<Parent ChangeTheworldevent={this.ChangeTheWorld.bind(this, "Changed")} 
			keepTheworldSameevent={this.ChangeTheWorld.bind(this, "Same")} 		
			title = {this.state.title} />
      </div>
    );
  }
}


class SampleFn extends React.Component{
	constructor(props){
		super(props);
		
	}
	SimpleFn=()=>{
		
		alert("Clicked");
	}
	
	render(){
		return (
		
			<App sample={this.SimpleFn} />
		);
		
	}
}


class Apicall extends React.Component{
	
	constructor(props){
		super(props);
		this.state= {
			Resdata:[]
		}
		
	}
	
	
	
	 Fetchdata=()=>{
	 fetch("http://www.omdbapi.com/?t=Interstellar&apikey=befcdfea")
		
		.then((response)=> response.json()
		
		).then((myJson)=>{
			
			var result = this.state.Resdata.concat(myJson);
			this.setState({Resdata: result});
			
		});
		
			
		}
		
	componentDidMount(){this.Fetchdata()}	
	
	
	
	render() {
    const {Resdata} = this.state;
		
      return (
	  <div>
		<div onClick={this.props.PassedFn}>Click</div>
		<Helmet>
                <meta charSet="utf-8" />
                <title>Api Call</title>
                <link rel="canonical" href="http://mysite.com/example" />
            </Helmet>
       <ul>
          {Resdata.map(item => (
            <li key={item.Title}>
              {item.Title} {item.Year}{item.Rated} {item.Released}
            </li>
          ))}
        </ul>
			<Apicall1 />
		</div>
      );
    
  }
}


class Clock extends Component{
	constructor(props){
		super(props);
		this.state = this.getTime();
	}
	
	componentDidMount() {
    this.setTime();
  }
  
  componentWillUnmount() {
    if (this.Timeout) {
      clearTimeout(this.Timeout);
    }
  }	
	
	setTime(){
		clearTimeout(this.Timeout);
		this.Timeout = setTimeout(this.updateClock.bind(this),1000); 
		
	}
	
	updateClock(){
    this.setState(this.getTime,this.setTime);
    
  }
	
getTime(){

const CurrentTime = new Date();

return{
	hours: CurrentTime.getHours(),
	minutes: CurrentTime.getMinutes(),
	seconds: CurrentTime.getSeconds(),
	ampm: CurrentTime.getHours() >= 12 ? 'pm' : 'am'
	}
	
}

render(){
const {hours, minutes, seconds, ampm} = this.state;
return(
		<div className="clock">
        {
          hours === 0 ? 12 :   (hours > 12) ?     hours - 12 : hours
        }:{
          minutes > 9 ? minutes : `0${minutes}`
        }:{
          seconds > 9 ? seconds : `0${seconds}`
        } {ampm}
		
		
      </div>
	  
	  
	  )
	
}	
}

class Header extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      searchVisible: false,
	  SearchTxt : '',
	  }
  }

  // toggle visibility when run on the state
  showSearch = ()=> {
   
   this.setState({
      searchVisible: !this.state.searchVisible
    })
  }
  
  SearchText=(e)=>{
	  
	  const val = e.target.value;
	  this.setState({
		  SearchTxt: val
		  
	  })
	  console.log(val);
  }
 
  render() {
    
    const wrapperStyle = {
      backgroundColor: 'rgba(251, 202, 43, 1)'
    }

    const titleStyle = {
      color: '#111111'
    }

    const menuColor = {
      backgroundColor: '#111111'
    }
	
	// Classes to add to the <input /> element
    let searchInputClasses = ["searchInput"];

    // Update the class array if the state is visible
    if (this.state.searchVisible) {
      searchInputClasses.push("active");
    }

    return (
      <div style={wrapperStyle} className="header">
	  
		<div className ="Header">	
			<div><h1 className="title">Hello,</h1></div>
			<div><input type="search"/> Search</div>
		</div>	
	  
        <div className="menuIcon">
          <div className="dashTop" style={menuColor}></div>
          <div className="dashBottom" style={menuColor}></div>
          <div className="circle" style={menuColor}></div>
        </div>

        <span style={titleStyle} className="title">
          {this.props.title}
        </span>

        <input onBlur={this.SearchText}
          type="text"
          className={searchInputClasses}
          placeholder="Search ..." />

        {/* Adding an onClick handler to call the showSearch button */}
        <div
          style={titleStyle}
          onClick={this.showSearch}
          className="searchIcon">|||</div>
		  <div>{this.SearchText}</div>
		 
      </div>
    )
  }
}


export default NavRoute;
