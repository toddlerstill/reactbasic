import React, {Component} from 'react'
import Child from './header'

class Footer extends React.Component{
	render(){
		return(
			<h2>{this.props.title}</h2>
		
		);
		
	}
	
}

const Parent = (props)=>{
	return(
		<div>
			<Child doWhatever={props.ChangeTheworldevent} title={props.title} />
			<Child doWhatever={props.keepTheworldSameevent} title={props.title} />
		</div>
	
	);
	
} 

export default Parent; 