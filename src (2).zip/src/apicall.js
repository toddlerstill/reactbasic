import React, {Component} from 'react';

export class Apicall1 extends React.Component{
	
	constructor(props){
		super(props);
		this.state={
			Data:[]
		}
		
	}
	
	
	fetchlist = () =>{
		
		fetch("http://www.omdbapi.com/?t=Dunkirk&apikey=befcdfea")
			.then((res)=>res.json())
			.then((Datares)=>{
				var Dataresult = this.state.Data.concat(Datares);
					
					this.setState({Data:Dataresult});
					
				});
		
	}
	
	componentDidMount(){this.fetchlist()}
	
	render() {
    const {Data} = this.state;

      return (
        <ul>
          {Data.map(item => (
            <li key={item.Title}>
              {item.Title} {item.Year}{item.Rated} {item.Released}
            </li>
          ))}
        </ul>
      );
    
  }
}

export default Apicall1