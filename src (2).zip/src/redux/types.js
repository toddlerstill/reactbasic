export const FETCH_NEW_TIME = 'FETCH_NEW_TIME';
