import * as types from './types';

export const fetchNewTime = () => ({
  type: types.FETCH_NEW_TIME,
})