import React, {Component} from 'react';

class Header extends Component{
	render()
	{
		return(
<div>
		<h2>{this.props.title}</h2>
		<img src={this.props.src} />
</div>		
	);
	
}
}

const Child = (props)=>{
		return(
	<div>
	<button onClick={props.doWhatever}>{props.title}</button>
		</div>
	)
}

export default Child;
